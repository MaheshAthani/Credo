import { Component, OnInit } from '@angular/core';
import { ChartDataSets } from 'chart.js';
import { Color, Label } from 'ng2-charts';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {

 ChartData: ChartDataSets[] = [
    { data: [85, 72, 78, 75, 80], label: 'Invoice Documents' },
  ];

  ChartLabels: Label[] = ['Invoice', 'UME', 'FBO', 'Dunning', 'SOA'];

  ChartOptions = {
    responsive: true,
  };

  ChartColors: Color[] = [
    {
      backgroundColor: ['rgb(12, 44, 64)','rgb(57, 125, 146)','rgb(242, 200, 162)','rgb(242, 147, 92)','rgb(217, 64, 50)']
    },
  ];

  ChartLegend = true;
  ChartPlugins = [];
  ChartType = 'doughnut';

    constructor() { }

  ngOnInit(): void {
  }

    // events
    public chartClicked(e:any):void {
      console.log(e);
    }
   
    public chartHovered(e:any):void {
      console.log(e);
    }
  }
